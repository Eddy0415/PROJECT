import { ChangeDetectionStrategy, Component, input, output } from '@angular/core';
import { UiPill } from '../ui-pill/ui-pill';

export interface SidebarItem {
  key: string;
  label: string;
  danger?: boolean;    
  disabled?: boolean;
}

@Component({
  selector: 'page-sidebar',
  standalone: true,
  imports: [UiPill],
  templateUrl: './page-sidebar.html',
  styleUrl: './page-sidebar.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})

export class PageSidebar {
  readonly items = input.required<SidebarItem[]>();
  readonly active = input<string>('');
  readonly action = output<string>();
}
